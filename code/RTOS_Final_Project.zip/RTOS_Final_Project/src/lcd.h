/**
 *  @file   lcd.h
 *  @brief  This file contains all lcd defines
 *  @author Justin Thwaites
 *  @date   2020-4-6
 ***********************************************/

#ifndef SRC_LCD_H_
#define SRC_LCD_H_

void  EX_Display_Task (void  *p_arg);

#endif /* SRC_LCD_H_ */
