/**
 *  @file   lcd.c
 *  @brief  This file holds the lcd task and all handling related to that task
 *  		.
 *  @author Justin Thwaites
 *  @date   2020-4-6
 ***********************************************/

void  EX_Display_Task (void  *p_arg){

}
