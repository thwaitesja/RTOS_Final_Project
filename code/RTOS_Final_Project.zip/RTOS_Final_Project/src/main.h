/**
 *  @file   main.h
 *  @brief  This file contains all main control functionality
 *  @author Justin Thwaites
 *  @date   2020-4-6
 ***********************************************/

#ifndef SRC_MAIN_H_
#define SRC_MAIN_H_
/******************Data Parameters******************************************/


/******************Project Include Files***********************************/
#include <stdint.h>
#include "em_device.h"
#include "em_chip.h"
#include "em_emu.h"
#include  <bsp_os.h>
#include "bsp.h"


#include  <cpu/include/cpu.h>
#include  <common/include/common.h>
#include  <kernel/include/os.h>
#include  <kernel/include/os_trace.h>

#include  <common/include/lib_def.h>
#include  <common/include/rtos_utils.h>
#include  <common/include/rtos_prio.h>
#include  <common/include/toolchains.h>

/******************User Include Files*****************************************/
#include "button.h"
#include "slider.h"
#include "physics.h"
#include "led.h"
#include "lcd.h"
#include "params.h"
/***************** DEFINES  **********************************************/

#define  PUSHBUTTON_TASK_PRIO            		18u
#define  PUSHBUTTON_TASK_STK_SIZE        		1024u

#define  CAPSENSE_SLIDER_TASK_PRIO            	19u
#define  CAPSENSE_SLIDER_TASK_STK_SIZE        	1024u

#define  DISPLAY_TASK_PRIO      	      		21u
#define  DISPLAY_TASK_STK_SIZE	        		2048u

#define  LED_TASK_PRIO          		  		20u
#define  LED_TASK_STK_SIZE		        		1024u

#define  PHYSICS_GENERATOR_TASK_PRIO           	17u
#define  PHYSICS_GENERATOR_TASK_STK_SIZE       	1024u

#define  MAINSTART_TASK_PRIO           			16u
#define  MAINSTART_TASK_STK_SIZE       			1024u

#define  IDLE_TASK_PRIO              			63u
#define  IDLE_TASK_STK_SIZE         			1024u


#define MSG_Q_QUANT								5
/********************************************************************************/

void  Ex_MainStartTask (void  *p_arg);

#endif /* SRC_MAIN_H_ */
