/**
 *  @file   main.c
 *  @brief  This file holds the setup for The whole final project including all the data for configuring the game,
 *  The main function sets up the startup task and all other functions
 *  		.
 *  @author Justin Thwaites
 *  @date   2020-4-6
 ***********************************************/


#include "main.h"


/***************************************************************************//**
 *   Global private Variables Section
 ******************************************************************************/

static  CPU_STK  MainStartTaskStk[MAINSTART_TASK_STK_SIZE];
static  CPU_STK  PushButtonTaskStk[PUSHBUTTON_TASK_STK_SIZE];
static  CPU_STK  CapsenseSliderTaskStk[CAPSENSE_SLIDER_TASK_STK_SIZE];
static  CPU_STK  DisplayTaskStk[DISPLAY_TASK_STK_SIZE];
static  CPU_STK  LedTaskStk[LED_TASK_STK_SIZE ];
static  CPU_STK  PhysicsGeneratorTaskStk[PHYSICS_GENERATOR_TASK_STK_SIZE];
static  CPU_STK  IdleTaskStk[IDLE_TASK_STK_SIZE];


/* Start Task TCB. */
static  OS_TCB   MainStartTaskTCB;
static  OS_TCB   PushButtonTaskTCB;
static  OS_TCB   CapsenseSliderTaskTCB;
static  OS_TCB   DisplayTaskTCB;
static  OS_TCB   LedTaskTCB;
static  OS_TCB   PhysicsGeneratorTaskTCB;
static  OS_TCB   IdleTaskTCB;


/***************************************************************************//**
 *   Global Variables Section
 ******************************************************************************/
OS_FLAG_GRP pushbutton_flags;
uint8_t led_nonblocking_flags;

OS_MUTEX force_percentage_mutex;
OS_MUTEX force_direction_mutex;

uint16_t force_percentage = 0;
slider_value force_direction_data = slider_center;

OS_SEM slider_semaphore;

OS_Q message_Q;


/***************************************************************************//**
 * @brief
 *   Idle_Task
 *   This function sets is the lowest priority task, letting the processor go into sleep mode once
 *   all other tasks have finished
 *
 * @param  p_arg
 * 	This is a pointer to all of the arguments the RTOS passes, it is not used since no arguments are required.
 *
 ******************************************************************************/

void  Idle_Task (void  *p_arg)
{
	PP_UNUSED_PARAM(p_arg);
	while(1){
		EMU_EnterEM1();
	}
}


/***************************************************************************//**
 * @brief
 *   Main function
 *   This function calls all of the setup functions for the RTOS, Then it calls OSInit,
 *   Adds the Vehicle Monitor task, and then starts the operating system.
 *
 * @note
 * 	 OSStart will never exit
 ******************************************************************************/
int main(void)
 {

	BSP_SystemInit();                                           /* Initialize System. */
	CPU_Init();                                                 /* Initialize CPU.  */
	Display_setup();


	OS_TRACE_INIT();

	OS_TASK_CFG  tmr_task_cfg = {    /*make the timer work at a faster speed to reduce slider latency*/
								  .StkBasePtr = DEF_NULL,
								  .StkSize = 256u,
								  .Prio = KERNEL_TMR_TASK_PRIO_DFLT,
								  .RateHz = 200u
								};
	OS_ConfigureTmrTask(&tmr_task_cfg);

	RTOS_ERR  err;
	OSInit(&err);                                               			/* Initialize the Kernel.*/
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);		/*   Check error code. */



	//Create Main Start Task
	  OSTaskCreate(&MainStartTaskTCB,
	                 "Main Start Task",
					  Ex_MainStartTask,
	                  DEF_NULL,
					  MAINSTART_TASK_PRIO,
	                  &MainStartTaskStk[0],
	                  (MAINSTART_TASK_STK_SIZE / 10u),
					  MAINSTART_TASK_STK_SIZE,
	                  0u,
	                  0u,
	                  DEF_NULL,
	                 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
	                 &err);
	    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */


    OSStart(&err);                                              /* Start the kernel. It should never exit this function*/
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1); /*   Check error code. */
    return (1);
}

/***************************************************************************//**
 * @brief
 *   Ex_MainStartTask
 *   This task takes care of setting up all of the RTOS tasks as well as any
 *   RTOS managed shared data structures, then it sleeps once done setting up
 *
 *
 * @param  p_arg
 *  pointer to unused passed arguments
 *

 ******************************************************************************/
void  Ex_MainStartTask (void  *p_arg){
	RTOS_ERR  err;
	params_init();

    //Create the message Queue
    OSQCreate (&message_Q, "Message queue 1", MSG_Q_QUANT ,&err);

    //Create the button flags
    OSFlagCreate(&pushbutton_flags, "Button Flags", 0 , &err);

    //Create the semaphore
	OSSemCreate(&slider_semaphore, "Capsense Semaphore", 0, &err);



	 //Create physics generator Task
		  OSTaskCreate(&PhysicsGeneratorTaskTCB,
		                 "Physics Generator Task",
						  Ex_PhysicsTask,
		                  DEF_NULL,
						  PHYSICS_GENERATOR_TASK_PRIO,
		                  &PhysicsGeneratorTaskStk[0],
		                  (PHYSICS_GENERATOR_TASK_STK_SIZE / 10u),
						  PHYSICS_GENERATOR_TASK_STK_SIZE,
		                  0u,
		                  0u,
		                  DEF_NULL,
		                 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
		                 &err);
		    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

		    //Create pushbutton Task
			  OSTaskCreate(&PushButtonTaskTCB,
							 "Pushbutton Task",
							  Ex_PushbuttonTask,
							  DEF_NULL,
							  PUSHBUTTON_TASK_PRIO,
							  &PushButtonTaskStk[0],
							  (PUSHBUTTON_TASK_STK_SIZE  / 10u),
							  PUSHBUTTON_TASK_STK_SIZE ,
							  0u,
							  0u,
							  DEF_NULL,
							 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
							 &err);
				APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

				 //Create capsense slider Task
			  OSTaskCreate(&CapsenseSliderTaskTCB,
							 "Capsense Slider Task",
							 EX_CapsenseSlider_Task,
							  DEF_NULL,
							  CAPSENSE_SLIDER_TASK_PRIO,
							  &CapsenseSliderTaskStk[0],
							  (CAPSENSE_SLIDER_TASK_STK_SIZE  / 10u),
							  CAPSENSE_SLIDER_TASK_STK_SIZE,
							  0u,
							  0u,
							  DEF_NULL,
							 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
							 &err);
				APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

				 //Create display Task
			  OSTaskCreate(&DisplayTaskTCB,
							 "Display Task",
							  EX_Display_Task,
							  DEF_NULL,
							  DISPLAY_TASK_PRIO,
							  &DisplayTaskStk[0],
							  (DISPLAY_TASK_STK_SIZE  / 10u),
							  DISPLAY_TASK_STK_SIZE,
							  0u,
							  0u,
							  DEF_NULL,
							 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
							 &err);
				APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

				 //Create LED Task
				  OSTaskCreate(&LedTaskTCB,
								 "LED Task",
								  EX_LED_Task,
								  DEF_NULL,
								  LED_TASK_PRIO,
								  &LedTaskStk[0],
								  (LED_TASK_STK_SIZE  / 10u),
								  LED_TASK_STK_SIZE,
								  0u,
								  0u,
								  DEF_NULL,
								 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
								 &err);
					APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */

					 //Create sleep Task
					  OSTaskCreate(&IdleTaskTCB,
									 "sleep Task",
									  Idle_Task,
									  DEF_NULL,
									  IDLE_TASK_PRIO,
									  &IdleTaskStk[0],
									  (IDLE_TASK_STK_SIZE  / 10u),
									  IDLE_TASK_STK_SIZE,
									  0u,
									  0u,
									  DEF_NULL,
									 (OS_OPT_TASK_STK_CLR|OS_OPT_TASK_STK_CHK),
									 &err);
						APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);    /*   Check error code.  */
						while(1){
							OSTimeDly(1000, OS_OPT_TIME_DLY, &err);
						}

}



