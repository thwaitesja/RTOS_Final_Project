/**
 *  @file   physics.c
 *  @brief  This file holds the physics task and all handling related to that task
 *  		.
 *  @author Justin Thwaites
 *  @date   2020-4-6
 ***********************************************/
#include "physics.h"
#include <math.h>

/***************************************************************************//**
 * @brief
 *   force generator
 *   This function takes in the atomic data from the two input tasks and the
 *   global max force and computes the force applied to the pendulum
 *
 * @param  direction
 * 	the direction of the pressed slider
 *
 *
 * @param  force percentage
 * 	the percentage of the max force determined by the buttons this is given as a number from 0-8 where 0 is 0% and 8 is 100%
 *
 * 	@param  max force
 * 	the determined max force on the base
 *
 ******************************************************************************/
int force_generator(slider_value direction, uint16_t force_percentage, uint32_t max_force){
	int force = (max_force*force_percentage)>>3; //max_f * f%/8
	switch(direction){
		case slider_center:
			return 0;
			break;
		case slider_farleft:
			return -1 * force;
			break;
		case slider_left:
			return -1*force>>1;
			break;
		case slider_right:
			return force>>1;
			break;
		case slider_farright:
			return force;
			break;
		default:
			while(1);
			break;
	}


}



/***************************************************************************//**
 * @brief
 *   physics engine
 *   This function takes in the current state of the pendulum data, the data configs the time step and the force
 *   and updates the current state
 *
 * @param  config
 * 	globally configured parameters
 *
 *
 * @param  force
 * 	the  irection of the applied force
 *
 * 	@param  time_step
 * 	how long the force is applied for
 *
 * @param  current state
 *  pointer to data holding what the current state is.
 *
 *
 *
 * @note   Fx = F(1-cos(2T))/2
 * 		   Fy = Fsin(2T)/2 + mg(d-1)
 ******************************************************************************/
bool physics_engine(struct Params config, int force, uint32_t time_step, struct State *current_state){
	/****************************************PRE CHECK************************************************/
	//exit if the angle is already on its side.
	if(current_state->angle == 90 || current_state->angle == -90){
		return true;
	}
	//exit if the State is already past the edge
	if((current_state->p_x <= config.xmin) || (current_state->p_x >= config.xmax)){
		return true;
	}
	/****************************************Force Computation************************************************/
	int f_x = force*(1-cos(((float)2*current_state->angle)/1024))/2;
	int f_y;
	if(current_state->angle){
		f_y = force*sin(((float)2*current_state->angle)/1024)/2 + config.gravity*config.post_mass;
	}
	else{//state is 0
		f_y = 0;
	}
	/****************************************Acceleration Computation************************************************/
	int a_x = f_x/config.post_mass;
	int a_y = f_y/config.post_mass;
	/****************************************Velocity Computation************************************************/
	current_state->v_x += a_x*time_step;
	current_state->v_y += a_y*time_step;
	/****************************************Position Computation************************************************/
	current_state->p_x += current_state->v_x*time_step;
	current_state->p_y += current_state->v_y*time_step;
	/****************************************Angle Computation************************************************/
	//check to make sure height approx isn't above pole length
	if(current_state->p_y > config.post_length ){//put the angle to 0 if crossing over
		current_state->p_y = config.post_length; //approximation oversteps -> this means a cross over on angle
		current_state->angle = 0;
	}
	else if(current_state->angle==0){//if at 0 make the angle slightly off so it begins falling
		if(current_state->v_x > 0){
			current_state->angle = 1;//starts going positive
		}
		else if(current_state->v_x < 0){
			current_state->angle = -1;//starts going negative
		}

	}
	else if(current_state->angle>0){//compute angle if not crossing over and in positive region
		current_state->angle = (int)(acos(((float)current_state->p_y) / config.post_length )*1024);
	}
	else if(current_state->angle<0){//compute angle if not crossing over and in negative region
		current_state->angle = (int)(-1*acos(((float)current_state->p_y) / config.post_length )*1024);
	}
	else{
		while(1);//error if goes here
	}


	/****************************************END Checks************************************************/

	//Check if the ball passed the min
	if(current_state->p_x <= config.xmin) {
		current_state->p_x = config.xmin;
		return true;
	}
	//Check if the ball passed the max
	if(current_state->p_x >= config.xmax) {
		current_state->p_x = config.xmax;
		return true;
	}

	//check if the angle horizontal
	if(current_state->angle >= 90){
		current_state->angle = 90;
		return true;
	}
	if(current_state->angle <= -90){
		current_state->angle = -90;
		return true;
	}
	return false;
}


void  Ex_PhysicsTask (void  *p_arg){

}
